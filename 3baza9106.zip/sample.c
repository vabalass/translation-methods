int main() {
    const int multiplier = 7;

    int two = multiplier * 2;
    int twenty_two = two + 6 + 2;

    printf("number: %d", twenty_two);
    
    return 0;
}

/* Grąžina: number: 22 */